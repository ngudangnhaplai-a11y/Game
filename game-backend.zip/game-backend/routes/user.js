// routes/user.js
// Route mẫu: lấy thông tin tài khoản đang đăng nhập
// Đây là ví dụ cho "Trang đầu" / "Tài khoản" sau này sẽ mở rộng thêm

const express = require('express');
const db = require('../config/database');
const requireAuth = require('../middleware/auth');

const router = express.Router();

router.get('/me', requireAuth, (req, res) => {
  const user = db
    .prepare('SELECT id, display_name, email, phone, avatar_url, score, created_at FROM users WHERE id = ?')
    .get(req.userId);

  if (!user) {
    return res.status(404).json({ error: 'Không tìm thấy tài khoản' });
  }

  res.json({ user });
});

module.exports = router;
