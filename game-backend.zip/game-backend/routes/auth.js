// routes/auth.js
// Xử lý: đăng ký thủ công (email/SĐT + mật khẩu), đăng nhập
// Đăng nhập bằng Gmail/Facebook sẽ làm ở bước sau (cần OAuth riêng)

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');

const router = express.Router();

// ---- ĐĂNG KÝ ----
router.post('/register', (req, res) => {
  const { display_name, email, phone, password } = req.body;

  // Validate cơ bản
  if (!display_name || !password) {
    return res.status(400).json({ error: 'Thiếu tên hiển thị hoặc mật khẩu' });
  }
  if (!email && !phone) {
    return res.status(400).json({ error: 'Cần ít nhất email hoặc số điện thoại' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Mật khẩu phải từ 6 ký tự trở lên' });
  }

  try {
    const password_hash = bcrypt.hashSync(password, 10);

    const stmt = db.prepare(`
      INSERT INTO users (display_name, email, phone, password_hash)
      VALUES (?, ?, ?, ?)
    `);
    const result = stmt.run(display_name, email || null, phone || null, password_hash);

    const token = jwt.sign({ userId: result.lastInsertRowid }, process.env.JWT_SECRET, {
      expiresIn: '30d',
    });

    res.status(201).json({
      message: 'Đăng ký thành công',
      token,
      user: { id: result.lastInsertRowid, display_name, email, phone },
    });
  } catch (err) {
    if (err.message.includes('UNIQUE constraint failed')) {
      return res.status(409).json({ error: 'Email hoặc số điện thoại đã được sử dụng' });
    }
    console.error(err);
    res.status(500).json({ error: 'Lỗi server, thử lại sau' });
  }
});

// ---- ĐĂNG NHẬP ----
router.post('/login', (req, res) => {
  const { identifier, password } = req.body; // identifier = email hoặc phone

  if (!identifier || !password) {
    return res.status(400).json({ error: 'Thiếu thông tin đăng nhập' });
  }

  const user = db
    .prepare('SELECT * FROM users WHERE email = ? OR phone = ?')
    .get(identifier, identifier);

  if (!user) {
    return res.status(401).json({ error: 'Tài khoản không tồn tại' });
  }

  const isValid = bcrypt.compareSync(password, user.password_hash);
  if (!isValid) {
    return res.status(401).json({ error: 'Sai mật khẩu' });
  }

  const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });

  res.json({
    message: 'Đăng nhập thành công',
    token,
    user: {
      id: user.id,
      display_name: user.display_name,
      email: user.email,
      phone: user.phone,
      avatar_url: user.avatar_url,
      score: user.score,
    },
  });
});

module.exports = router;
