# Game Backend — Bước 1: Đăng ký / Đăng nhập

Đây là backend nhỏ nhất có thể chạy thật: đăng ký tài khoản (email/SĐT + mật khẩu),
đăng nhập, lấy thông tin tài khoản. Dùng SQLite nên không cần cài database riêng.

## Cách chạy trên VPS

### 1. Cài Node.js (nếu VPS chưa có)
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # kiểm tra đã cài, nên là v20.x
```

### 2. Đưa code lên VPS
Cách dễ nhất: push code này lên GitHub repo "Game" của m, sau đó trên VPS chạy:
```bash
git clone https://github.com/ngudangnhaplai-a11y/Game.git
cd Game
```
(Thay đúng đường dẫn thư mục backend nếu m để chung với các phần khác)

### 3. Cài dependencies
```bash
npm install
```

### 4. Tạo file .env
```bash
cp .env.example .env
nano .env
```
Sửa `JWT_SECRET` thành 1 chuỗi bí mật dài, khó đoán (đừng dùng chuỗi mẫu).

### 5. Chạy thử
```bash
npm start
```
Nếu thấy dòng `✅ Server đang chạy tại http://localhost:3000` là thành công.

### 6. Test bằng curl (mở terminal khác, hoặc dùng app Termius/JuiceSSH trên điện thoại)

**Đăng ký:**
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"display_name":"Test User","email":"test@example.com","password":"123456"}'
```

**Đăng nhập:**
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"identifier":"test@example.com","password":"123456"}'
```

**Lấy thông tin tài khoản** (thay YOUR_TOKEN bằng token nhận được ở bước đăng nhập):
```bash
curl http://localhost:3000/api/user/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 7. Chạy nền lâu dài (để tắt terminal server vẫn sống)
```bash
npm install -g pm2
pm2 start server.js --name game-backend
pm2 save
```

## Bước tiếp theo (sau khi cái này chạy ổn)
- Mở port qua Nginx + domain + SSL để app mobile gọi được từ bên ngoài
- Thêm đăng nhập Gmail/Facebook (OAuth)
- Thêm API: điểm số, bảng xếp hạng, danh sách game
