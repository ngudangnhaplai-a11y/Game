// config/database.js
// Dùng SQLite cho giai đoạn đầu — nhẹ, không cần cài server database riêng.
// Sau này khi app lớn hơn, có thể đổi sang PostgreSQL/MySQL mà không cần sửa nhiều code.

const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', 'data.db'));

// Bật chế độ WAL để đọc/ghi đồng thời tốt hơn
db.pragma('journal_mode = WAL');

// Tạo bảng users nếu chưa tồn tại
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    display_name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    avatar_url TEXT DEFAULT NULL,
    score INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

module.exports = db;
